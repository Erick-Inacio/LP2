﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCotacao
{
    public partial class frmCotacao : Form
    {
        public frmCotacao()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            double[,] lojaEPreco = new double[10, 3];
            double[] mediasModelos = new double[10];

            double media = 0;
            double mediaFinal = 0;

            // entrada de valores
            for (int i = 0; i < lojaEPreco.GetLength(0); i++)
            {
                media = 0;
                for (int j = 0; j < lojaEPreco.GetLength(1); j++)
                {
                    if (double.TryParse(Interaction.InputBox($"Digite o preço na Loja {j + 1}", $"Modelo do {i + 1}º notebook"), out lojaEPreco[i, j]) &&
                       lojaEPreco[i, j] > 0)
                    {
                        media += lojaEPreco[i, j];
                        
                    }
                    else
                    {
                        j--;
                    }
                }
                mediasModelos[i] = media / 3;
                //MessageBox.Show(mediasModelos[i].ToString());
            }

            for (int i = 0; i < lojaEPreco.GetLength(0); i++)
            {
                mediaFinal = mediasModelos[i];
            }

            mediaFinal = mediaFinal / lojaEPreco.GetLength(0);

            //saída de dados no listbox
            for (int i = 0; i < lojaEPreco.GetLength(0); i++)
            {
                lsbxModelo.Items.Add($"Notebook {i + 1} Loja 1 R$ {lojaEPreco[i, 0].ToString("N2")}" +
                    $" Loja 2 R$ {lojaEPreco[i, 1].ToString("N2")} Loja 3 R$ {lojaEPreco[i, 1].ToString("N2")} " +
                    $"Média {mediasModelos[i].ToString("N2")}");
            }

            lsbxModelo.Items.Add("\n");
            lsbxModelo.Items.Add("-----------------------------------------------");
            lsbxModelo.Items.Add($"Média Geral de Computadores: {mediaFinal.ToString("N2")}");
        }
    }
}
